(function($) {
    'use strict';
    $(function() {
        var hard_prevent = function(e){
            e.preventDefault();
            e.stopPropagation();
            e.stopImmediatePropagation();
        };

        var video_modal = $('#video-modal');

        $('.video-btn').click(function(e) {
            hard_prevent(e);
            var src = $(this).data('src');
            $('#video-modal-iframe').attr('src',src);
            video_modal.modal('show');
        });

        video_modal.on('hide.bs.modal', function (e) {
            $('iframe',this).attr('src','');
        });
    }); // end document ready
})(jQuery, this);

